from LinkedList import LinkedList

if __name__ == "__main__":
    ls = LinkedList() # An initially empty linked list
    ls.prepend(4)
    ls.prepend(6)
    ls.prepend(3)
    print(ls)
    ls.insert(2, 8)
    print(ls)
    ls.insert(0, 9)
    print(ls)
    # ls.insert(-1, 2024) # This throws an error
    ls.insert(5, 7)
    print(ls)
    ls.insert(7, 2025)
    # ls.foo() # Since we call `foo()` from an **object** `ls` takes the place of the first argument.
    # LinkedList.foo("Bob") # Since we call `foo()` from the **class**, we have to pass the first argument.
    # ls.foo("mess") # This throws an error, since the first argument of `foo()` is `ls`
    # and the second one would be `"mess"`, but `foo()` accepts only one argument!