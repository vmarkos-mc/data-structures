#include <stdio.h>

int main() {
    printf("Hello, World!");
    return 0;
}

/*
ISO C++

```cpp
int n;
cin >> in;
int arr[n];
```

The above throws an error using MS Visual C++ compiler!!

The above, however, is not a problem for GNU compilers (g++, gdb, ...)
*/