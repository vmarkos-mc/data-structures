# in-class/LinkedList.py

class Node:
    def __init__(self, contents, next_node):
        self.contents = contents # This contains the contents of a node, e.g., an int, a str...
        self.next_node = next_node # This points to the next node in a linked list

    def __str__(self):
        """
        This determines how a node is casted to string.
        """
        return str(self.contents)
    
class LinkedList:
    """
    This is a class representing a linked list, i.e.:
        * contains a `self.start` node, which is a node with no contents (`None`)
          pointing to the last node of the list, i.e., `None`.
        * the last node of the list points to `None` as its next node, i.e., 
          `self.next_node == None` only in this case.
    """
    def __init__(self):
        """
        `self.start` initially points to nowhere, because the list is empty

        ```
        start   --> end
          ^
        (None)  --> None
        ```
        """
        self.start = Node(None, None)

    def prepend(self, contents):
        """
        Prepends `contents` to a new node at the beginning of the list.
        Initially:
        start --> N1 --> N2 --> ... --> None
        prepend(N0):
        start --> N0 --> N1 --> ... --> None
        """
        new_node = Node(contents, self.start.next_node)
        self.start.next_node = new_node

    def insert(self, i, contents):
        """
        This function inserts a new node with contents `contents` in position `i`.
        """
        if i < 0: # We do not support negative indices
            raise ValueError(f"Invalid value for 'i == {i}'.")
            # raise IndexError(f"Index out of bounds: '{i}'.")
        current_node = self.start # Start from the start of the list
        k = 0
        while current_node.next_node != None and k < i:
            current_node = current_node.next_node
            k += 1
        if i > k:
            raise ValueError(f"Invalid value for 'i == {i}'.")
            # raise IndexError(f"Index out of bounds: '{i}'.")
        # At this point, `current_node` is the node at `i-1`.
        new_node = Node(contents, current_node.next_node)
        current_node.next_node = new_node
        # `Paraphrase` the loop in `__str__` to access the list element at `i`.
        # What we want to implement is:
        #
        # ```
        # start -> 5 -> 3 -> 1 -> 2 -> end
        #          0    1    2    3
        # ```
        #
        # So, `insert(2, 8)`, the result should be as follows:
        #
        # ```
        # start -> 5 -> 3 -> 8 -> 1 -> 2 -> end
        #          0    1    2    3    4
        # ```
        # So, this update can be performed as follows:
        #   1. First, "walk" all the way until index 1 (3 in our case);
        #   2. Then, create the new node, containing 8, and pointing to 1 (the former node at
        #      index 2);
        #   3. Then, the node at index 1 points to the new node.

    def remove(self, i):
        """
        This function removes the list node at position `i`.
        """
        pass

    def foo(bar):
        # This is just to demonstrate "class" and "object" methods differences.
        print(f"You are not cool, {bar}!")

    def __str__(self):
        out_str = "[ "
        current_node = self.start # Start from the start of the list.
        while current_node.next_node != None: # Repeat until we reach the end of the list
            current_node = current_node.next_node
            out_str = out_str + str(current_node) + " "
        out_str = out_str + "]"
        return out_str