# in-class/Heap.py

class Heap:
    """Implements a binary heap assuming contents are numbers"""
    def __init__(self):
        """Initialised the heap"""
        self.nodes = [] # Just an empty list of "nodes", initially.

    def __get_left_child(self, node):
        """Returns the left child `node`"""
        pass

    def __get_right_child(self, node):
        """Returns the right child `node`"""
        pass

    def __get_parent(self, node):
        """Returns the parent of `node`"""
        pass

    def insert(self, entry):
        """Inserts a new node to the heap"""
        pass

    def extract_max(self):
        """Returns the maximum element of the heap and restructures the heap appropriately"""
        pass

    def peek(self):
        """Returns the maximum element of the heap"""
        if self.nodes == []:
            raise ValueError("Heap is Empty!")
        return self.nodes[0]